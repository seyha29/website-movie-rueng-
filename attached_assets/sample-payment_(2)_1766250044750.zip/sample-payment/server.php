<?php
if(!empty($_POST["price"])){

    $transaction_id = time();
    $amount = $_POST["price"];

    $my_payment_url = "https://raksmeypay.com/payment/request/5eebfa4ea9e0f54a55bd13e19e3fae84";
    $profile_key = "0d99342d0ca34efc1474c74b50088f7a7da602e1168d664b2b47a41a8e2b14b3301d2abc80540c77";
    $success_url = urlencode("http://localhost/sample-payment/payment_success.php?transaction_id=".$transaction_id."&amount=".$amount);
    $hash = sha1($profile_key . $transaction_id . $amount . $success_url);
    $parameters = [
        "transaction_id" => $transaction_id,
        "amount" => $amount,
        "success_url" => $success_url,
        "hash" => $hash
    ];
    $queryString = http_build_query($parameters);
    $payment_link_url = $my_payment_url."?".$queryString;
    echo json_encode(["success" => 1, "payment_link" => $payment_link_url]);
}