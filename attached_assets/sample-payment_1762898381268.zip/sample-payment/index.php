<!DOCTYPE html>
<html>
<head>
    <title>Payment Link</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#submitBtn').click(function(event) {
                event.preventDefault(); // Prevent the default form submission
                var price = $('#price').val();
                if( price == ''){
                    alert("Please input price");
                    return;
                }
                $.ajax({
                    url: 'server.php',
                    type: 'POST',
                    dataType: 'JSON',
                    data: {price: price},
                    success: function(response) {
                        if(response.success == 1){
                            window.location.href = response.payment_link;
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(error);
                    }
                });
            });
        });
    </script>
</head>
<body>
<h1>Payment Link</h1>
<label for="price">Price:</label>
<input type="number" id="price" name="price" required>
<button id="submitBtn">Pay Now</button>
</body>
</html>