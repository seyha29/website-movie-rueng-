<?php
if(!empty($_GET["transaction_id"])){
    $transaction_id = $_GET["transaction_id"];
    $amount = $_GET["amount"];

    $payment_verify_url = "https://raksmeypay.com/api/payment/verify/5eebfa4ea9e0f54a55bd13e19e3fae84";
    $profile_key = "0d99342d0ca34efc1474c74b50088f7a7da602e1168d664b2b47a41a8e2b14b3301d2abc80540c77";
    $hash = sha1($profile_key . $transaction_id);
    $data = [
        "transaction_id" => $transaction_id,
        "hash" => $hash
    ];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $payment_verify_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    $response = json_decode($response, 1);
    if(!empty($response["payment_status"]) && strtoupper($response["payment_status"]) == "SUCCESS" && $response["payment_amount"] == $amount){
        echo "<h1>Thank for you Payment</h1>";

        //Your code here

    }
}